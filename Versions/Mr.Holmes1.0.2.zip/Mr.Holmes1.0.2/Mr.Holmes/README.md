<p align="center">
  <img width="200" height="200" src="Icon/Mr.Holmes.png">
</p>

# Mr.Holmes 
### Mr.Holmes is a information gathering tool (OSINT). Is main purpose is to gain information about domains,username and phone numbers with the help of public source avaiable on the internet also it use the google dorks attack for specific researchers. It also use proxies for make your requests completley anonymous and a WhoIS Api for getting more information about a domain.

# DISCLAIMER
### This Tool is Not 100% Precise so it can fail somtimes. Also this tool is made for educational and research purposes only..use it wisely

# SCREENSHOT
![Screenshot](Screenshot/Screenshot.png)
# INSTALLATION:
    git clone https://github.com/Lucksi/Mr.Holmes.git
    cd Mr.Holmes
    sudo ./install.sh

# USAGE:
    python3 Mr.Holmes.py
# API KEY LINK:
    https://whois.whoisxmlapi.com
# Configuration:
    Configuration/Configuration.yaml
