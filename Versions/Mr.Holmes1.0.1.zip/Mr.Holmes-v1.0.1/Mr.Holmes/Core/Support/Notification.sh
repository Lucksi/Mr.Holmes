#!/bin/sh
zenity --notification    --window-icon="info"     --text="Process finished"